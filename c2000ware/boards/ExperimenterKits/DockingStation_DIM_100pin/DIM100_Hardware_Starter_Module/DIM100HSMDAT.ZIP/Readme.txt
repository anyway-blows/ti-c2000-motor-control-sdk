Key to Database files

Jobname = TEX016


*.PCB 		Innoveda database (binary)
*.ASC		Innoveda database (ASCII)
*.dxf		DXF of entire database
*.net		Netlist derived from board

