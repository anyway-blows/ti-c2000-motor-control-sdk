Key to Assembly files

Jobname = TEX017

FILENAME:	-    Description:			   FORMAT:	
---------	     ------------			   -------
*.XYR		-    Generic X-Y Placement Data	   	   ASCII 		
*asy.PDF 	-    Assembly Drawing		   	   ADOBE PDF
PST.PHO		-    Primary Side Solder Stencil Data      Gerber 3.5
SST.PHO		-    Secondary Side Solder Stencil Data    Gerber 3.5		#
*.ASC  	-    PADS PowerPCB V3.5 ASCII Database	   ASCII Current Units
*.TPR	-    Test Point Data	                   ASCII 		@




# Not in package if no bottom assembly. 

@ Not in package if no ict test points.