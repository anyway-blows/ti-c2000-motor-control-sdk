
Key to Database files

Jobname = TEX017


*.PCB 		Innoveda database (binary)
*.ASC		Innoveda database (ASCII)
*.dxf		DXF of entire database
*.net		Netlist derived from board

